This is the Project #0 in class CS 310. 
There are three classes Nodes, TwoItemBox and TwoItemBoxDemo. 
In class Nodes, I practice how to use generics, write JavaDocs, and use the basic command line tools. 
In class TwoItemBox, I practice how to use command line arguments and write basic Java code
(including exception handling). 
Besides that, I also practice style checking, Javadocs checking and Junit for those two classes.
In class TwoItemBoxDemo, I check the result of the the two getter methods of the class TwoItemBox. 

